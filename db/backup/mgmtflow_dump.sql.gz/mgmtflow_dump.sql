--
-- PostgreSQL database dump
--

\restrict QccT77WCTbC6yIqckfswnI1a3z7jXhbpvTlyoSTdHIcMxgQhlWEn5tCawiQNzUQ

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS jobs_workflow_id_fkey;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS jobs_flow_definition_id_fkey;
ALTER TABLE IF EXISTS ONLY public.flow_tasks DROP CONSTRAINT IF EXISTS flow_tasks_job_id_fkey;
DROP INDEX IF EXISTS public.idx_jobs_workflow_id;
DROP INDEX IF EXISTS public.idx_jobs_status;
DROP INDEX IF EXISTS public.idx_flow_tasks_status;
DROP INDEX IF EXISTS public.idx_flow_tasks_job_id;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_pkey;
ALTER TABLE IF EXISTS ONLY public.jobs DROP CONSTRAINT IF EXISTS jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.flow_tasks DROP CONSTRAINT IF EXISTS flow_tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.flow_definitions DROP CONSTRAINT IF EXISTS flow_definitions_pkey;
ALTER TABLE IF EXISTS ONLY public.flow_definitions DROP CONSTRAINT IF EXISTS flow_definitions_display_id_key;
ALTER TABLE IF EXISTS public.workflows ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.flow_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.flow_definitions ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.workflows_id_seq;
DROP TABLE IF EXISTS public.workflows;
DROP SEQUENCE IF EXISTS public.jobs_id_seq;
DROP TABLE IF EXISTS public.jobs;
DROP SEQUENCE IF EXISTS public.flow_tasks_id_seq;
DROP TABLE IF EXISTS public.flow_tasks;
DROP SEQUENCE IF EXISTS public.flow_definitions_id_seq;
DROP TABLE IF EXISTS public.flow_definitions;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flow_definitions; Type: TABLE; Schema: public; Owner: mgmtflow
--

CREATE TABLE public.flow_definitions (
    id integer NOT NULL,
    display_id text NOT NULL,
    package_id text,
    name text NOT NULL,
    version text,
    definition jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.flow_definitions OWNER TO mgmtflow;

--
-- Name: flow_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: mgmtflow
--

CREATE SEQUENCE public.flow_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.flow_definitions_id_seq OWNER TO mgmtflow;

--
-- Name: flow_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mgmtflow
--

ALTER SEQUENCE public.flow_definitions_id_seq OWNED BY public.flow_definitions.id;


--
-- Name: flow_tasks; Type: TABLE; Schema: public; Owner: mgmtflow
--

CREATE TABLE public.flow_tasks (
    id integer NOT NULL,
    job_id integer NOT NULL,
    seq integer NOT NULL,
    display_id text NOT NULL,
    task_type text NOT NULL,
    params jsonb NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    container_id text,
    exit_code integer,
    output text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT flow_tasks_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'complete'::text, 'failed'::text]))),
    CONSTRAINT flow_tasks_task_type_check CHECK ((task_type = ANY (ARRAY['shell'::text, 'python'::text])))
);


ALTER TABLE public.flow_tasks OWNER TO mgmtflow;

--
-- Name: flow_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: mgmtflow
--

CREATE SEQUENCE public.flow_tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.flow_tasks_id_seq OWNER TO mgmtflow;

--
-- Name: flow_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mgmtflow
--

ALTER SEQUENCE public.flow_tasks_id_seq OWNED BY public.flow_tasks.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: mgmtflow
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    workflow_id integer,
    name text NOT NULL,
    status text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    triggered_by text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    flow_definition_id integer,
    CONSTRAINT jobs_progress_check CHECK (((progress >= 0) AND (progress <= 100))),
    CONSTRAINT jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'complete'::text, 'failed'::text])))
);


ALTER TABLE public.jobs OWNER TO mgmtflow;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: mgmtflow
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO mgmtflow;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mgmtflow
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: mgmtflow
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    schedule text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflows OWNER TO mgmtflow;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: mgmtflow
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO mgmtflow;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: mgmtflow
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: flow_definitions id; Type: DEFAULT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_definitions ALTER COLUMN id SET DEFAULT nextval('public.flow_definitions_id_seq'::regclass);


--
-- Name: flow_tasks id; Type: DEFAULT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_tasks ALTER COLUMN id SET DEFAULT nextval('public.flow_tasks_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: flow_definitions; Type: TABLE DATA; Schema: public; Owner: mgmtflow
--

COPY public.flow_definitions (id, display_id, package_id, name, version, definition, created_at, updated_at) FROM stdin;
1	bootstrap	sco_common	Bootstrap	1.0	{"desc": "Bootstrap flow", "name": "Bootstrap", "tasks": [{"name": "Perform prerequisite", "display_id": "execute_commands_on_nodes", "package_id": "sco_common", "plugin_params": {"commands": ["echo hello from task", "uname -a"]}}], "version": "1.0", "display_id": "bootstrap", "flow_level": "Node", "package_id": "sco_common"}	2026-08-15 21:10:56.377578+00	2026-08-15 21:10:56.377578+00
2	python-smoke-test	\N	Python smoke test	\N	{"name": "Python smoke test", "tasks": [{"display_id": "print_hi", "plugin_params": {"code": "print(2+2)"}}], "display_id": "python-smoke-test"}	2026-08-15 21:11:25.831365+00	2026-08-15 21:11:25.831365+00
3	chain-test	\N	Chain test	\N	{"name": "Chain test", "tasks": [{"display_id": "step1", "plugin_params": {"commands": ["echo step1"]}}, {"display_id": "step2", "plugin_params": {"code": "print(\\"step2\\")"}}, {"display_id": "step3", "plugin_params": {"commands": ["echo step3"]}}], "display_id": "chain-test"}	2026-08-15 21:13:31.228166+00	2026-08-15 21:13:31.228166+00
4	fail-test	\N	Fail test	\N	{"name": "Fail test", "tasks": [{"display_id": "boom", "plugin_params": {"commands": ["exit 1"]}}, {"display_id": "never", "plugin_params": {"commands": ["echo should-not-run"]}}], "display_id": "fail-test"}	2026-08-15 21:13:54.525036+00	2026-08-15 21:13:54.525036+00
6	sleep-30	\N	Sleep 30s	\N	{"name": "Sleep 30s", "tasks": [{"display_id": "long_running_task", "plugin_params": {"commands": ["echo starting", "sleep 30", "echo done sleeping"]}}], "display_id": "sleep-30"}	2026-08-15 21:37:17.528552+00	2026-08-15 21:37:17.528552+00
\.


--
-- Data for Name: flow_tasks; Type: TABLE DATA; Schema: public; Owner: mgmtflow
--

COPY public.flow_tasks (id, job_id, seq, display_id, task_type, params, status, container_id, exit_code, output, started_at, completed_at, created_at) FROM stdin;
1	5	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	5a822ac20a815a6170009d762bcdaf432a85633784accf68d2c9fc2ac3755b49	0	hello from task\r\nLinux 5a822ac20a81 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:11:01.35955+00	2026-08-15 21:11:04.254752+00	2026-08-15 21:11:01.270457+00
2	6	0	print_hi	python	{"code": "print(2+2)"}	failed	f880ae4b70832520acf0ae5dbf0ccd2a0cfba24a3a5414bef1689f39e4e04834	\N	engine error: toString() radix argument must be between 2 and 36	2026-08-15 21:11:32.111247+00	2026-08-15 21:11:37.841092+00	2026-08-15 21:11:32.095077+00
3	7	0	print_hi	python	{"code": "print(2+2)"}	complete	92dea73a470696b6f8cdc0ce141c767acda0533aac33e9305624c47da50f7762	0	4	2026-08-15 21:13:17.250381+00	2026-08-15 21:13:17.933921+00	2026-08-15 21:13:17.222617+00
12	13	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	86b94e6fe561a78afb5b0255460a0becd755296527b9a53f7b0cf55d9640205f	0	hello from task\r\nLinux 86b94e6fe561 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:30:12.92106+00	2026-08-15 21:30:13.45871+00	2026-08-15 21:30:12.914749+00
4	8	0	step1	shell	{"commands": ["echo step1"]}	complete	d750f1f54f8fee2978fa07a7770b80323b4bcd64d40d5591366e0658d713f770	0	step1\r\n	2026-08-15 21:13:35.160816+00	2026-08-15 21:13:35.801766+00	2026-08-15 21:13:35.143052+00
5	8	1	step2	python	{"code": "print(\\"step2\\")"}	complete	1fe1a402650b157aa61d95860db10ce7df150647f78dc140b05d8d4e1654a849	0	step2\r\n	2026-08-15 21:13:35.824138+00	2026-08-15 21:13:36.727789+00	2026-08-15 21:13:35.143052+00
6	8	2	step3	shell	{"commands": ["echo step3"]}	complete	2acce6949ce15c0814dfa5d68993e90504396377e71863d63ca8d343ed080b3c	0	step3\r\n	2026-08-15 21:13:36.738202+00	2026-08-15 21:13:37.516364+00	2026-08-15 21:13:35.143052+00
8	9	1	never	shell	{"commands": ["echo should-not-run"]}	queued	\N	\N	\N	\N	\N	2026-08-15 21:13:58.638156+00
7	9	0	boom	shell	{"commands": ["exit 1"]}	failed	43270c3e94a8ea4462461430dd5e3d3129938bd8246404dccb8725bab57f5f49	1		2026-08-15 21:13:58.654881+00	2026-08-15 21:13:59.226639+00	2026-08-15 21:13:58.638156+00
13	14	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	f9a1e99702d7dc08910c940a7dff7f9e977932270de24b4897a678254a175094	0	hello from task\r\nLinux f9a1e99702d7 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:31:14.003923+00	2026-08-15 21:31:14.591427+00	2026-08-15 21:31:13.983362+00
9	10	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	31e9a8ea085ed74b266d7614801193017824b4186d954565864ce81e1e568129	0	hello from task\r\nLinux 31e9a8ea085e 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:28:43.330738+00	2026-08-15 21:28:43.948336+00	2026-08-15 21:28:43.225283+00
10	11	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	4c61b9b71b6dca3b22fb8ea1aa68b9d63d66aa0717c1809e0cdefc5cb9753a60	0	hello from task\r\nLinux 4c61b9b71b6d 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:29:58.524124+00	2026-08-15 21:29:59.106933+00	2026-08-15 21:29:58.506833+00
11	12	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	e298f946b574ddd1f59eda467fc173cf64e3124de602de274c0ff90bf7a214db	0	hello from task\r\nLinux e298f946b574 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:30:07.591374+00	2026-08-15 21:30:08.202469+00	2026-08-15 21:30:07.583576+00
22	23	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	4fae01a8702ed0976cf430b5aa4d21d160a93209201f059cc35e23da1632dc8c	0	hello from task\r\nLinux 4fae01a8702e 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 22:10:02.837492+00	2026-08-15 22:10:05.172056+00	2026-08-15 22:10:02.78668+00
14	15	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	2bd1383cdad959e07dcd537782b103bc6c68a2c08ca4cac2752395547fa9d0de	0	starting\r\ndone sleeping\r\n	2026-08-15 21:37:25.731786+00	2026-08-15 21:37:56.255687+00	2026-08-15 21:37:25.710951+00
17	18	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	b342e53f9ea97cdf097d6fbae286bebebef2f2b89abc18212f917b6dd0e701bd	0	starting\r\ndone sleeping\r\n	2026-08-15 21:43:51.479317+00	2026-08-15 21:44:22.000154+00	2026-08-15 21:43:51.393872+00
15	16	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	7f7189b026aa91d6155f22198bfab0f416d4892f2ba940ee4ef7462ff5e5dd58	0	hello from task\r\nLinux 7f7189b026aa 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 21:41:09.837341+00	2026-08-15 21:41:10.398896+00	2026-08-15 21:41:09.81456+00
16	17	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	ca051a1abd67c14c7ecec436d3754f7a23aa9a59ad13bd0ba2009faf40454943	0	starting\r\ndone sleeping\r\n	2026-08-15 21:41:37.332018+00	2026-08-15 21:42:07.9402+00	2026-08-15 21:41:37.309763+00
20	21	0	print_hi	python	{"code": "print(2+2)"}	complete	32a9118de33e263dd203061061f2ef4a97d32902b192ae163408e3a79dc63737	0	4\r\n	2026-08-15 22:08:36.153559+00	2026-08-15 22:08:36.913848+00	2026-08-15 22:08:36.145733+00
18	19	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	e987cee13139a1a8d3497a8f17f7fbf24e2ec37b8f2888c7641a59901df3f62c	0	starting\r\ndone sleeping\r\n	2026-08-15 21:50:21.71495+00	2026-08-15 21:50:52.261226+00	2026-08-15 21:50:21.695184+00
19	20	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	26d0bc97462d5bc2cdaaede04c302d6bf695e9709a29135622d0d33aa5d9491e	0	hello from task\r\nLinux 26d0bc97462d 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 22:08:17.749682+00	2026-08-15 22:08:18.401555+00	2026-08-15 22:08:17.661613+00
21	22	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	fcd5b564737eaef32be2f7773d6ea60dd5a17cb6ff1604446190943e8129f0dc	0	starting\r\ndone sleeping\r\n	2026-08-15 22:08:44.777777+00	2026-08-15 22:09:15.409096+00	2026-08-15 22:08:44.770757+00
23	24	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	e06e2ae4b5e2833d66436105bd65bea3ba548295957c43f6d86430d24b50ab13	0	hello from task\r\nLinux e06e2ae4b5e2 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-15 22:33:03.381195+00	2026-08-15 22:33:03.994011+00	2026-08-15 22:33:03.371712+00
24	25	0	execute_commands_on_nodes	shell	{"commands": ["echo hello from task", "uname -a"]}	complete	8b935eb0e61f12dc4456cf08fa788c332b0f3b4b9831c3e4d7c49d67bf64313e	0	hello from task\r\nLinux 8b935eb0e61f 6.12.72-linuxkit #1 SMP PREEMPT_DYNAMIC Wed Feb 25 13:22:15 UTC 2026 x86_64 Linux\r\n	2026-08-17 05:24:54.003756+00	2026-08-17 05:24:54.776461+00	2026-08-17 05:24:53.991636+00
25	26	0	long_running_task	shell	{"commands": ["echo starting", "sleep 30", "echo done sleeping"]}	complete	bd943e6b1cdfe7a4999b640e35dd6099b900d92de0e769281a5e98489a327703	0	starting\r\ndone sleeping\r\n	2026-08-21 07:07:04.364213+00	2026-08-21 07:07:35.016658+00	2026-08-21 07:07:04.347931+00
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: mgmtflow
--

COPY public.jobs (id, workflow_id, name, status, progress, triggered_by, started_at, completed_at, created_at, flow_definition_id) FROM stdin;
1	\N	deploy-prod-api-gateway	running	70	dtrubitsyn	2026-08-15 20:22:52.505176+00	\N	2026-08-15 20:24:52.505176+00	\N
2	3	nightly-backup-db-cluster	queued	0	schedule	\N	\N	2026-08-15 20:24:52.505176+00	\N
3	\N	migrate-schema-billing-service	failed	60	dtrubitsyn	2026-08-15 19:59:52.505176+00	2026-08-15 20:06:52.505176+00	2026-08-15 20:24:52.505176+00	\N
4	\N	rotate-secrets-auth-service	complete	100	svc-ci-runner	2026-08-15 19:34:52.505176+00	2026-08-15 19:46:52.505176+00	2026-08-15 20:24:52.505176+00	\N
5	\N	Bootstrap	complete	100	dima-test	2026-08-15 21:11:01.364666+00	2026-08-15 21:11:04.267635+00	2026-08-15 21:11:01.270457+00	1
6	\N	Python smoke test	failed	0	\N	2026-08-15 21:11:32.11544+00	2026-08-15 21:11:37.844337+00	2026-08-15 21:11:32.095077+00	2
7	\N	Python smoke test	complete	100	\N	2026-08-15 21:13:17.257774+00	2026-08-15 21:13:17.941061+00	2026-08-15 21:13:17.222617+00	2
8	\N	Chain test	complete	100	\N	2026-08-15 21:13:35.16466+00	2026-08-15 21:13:37.521804+00	2026-08-15 21:13:35.143052+00	3
9	\N	Fail test	failed	0	\N	2026-08-15 21:13:58.659625+00	2026-08-15 21:13:59.228555+00	2026-08-15 21:13:58.638156+00	4
10	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:28:43.336908+00	2026-08-15 21:28:43.959517+00	2026-08-15 21:28:43.225283+00	1
11	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:29:58.528183+00	2026-08-15 21:29:59.11311+00	2026-08-15 21:29:58.506833+00	1
12	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:30:07.592561+00	2026-08-15 21:30:08.207367+00	2026-08-15 21:30:07.583576+00	1
13	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:30:12.923559+00	2026-08-15 21:30:13.463923+00	2026-08-15 21:30:12.914749+00	1
14	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:31:14.007868+00	2026-08-15 21:31:14.597563+00	2026-08-15 21:31:13.983362+00	1
15	\N	Sleep 30s	complete	100	dima	2026-08-15 21:37:25.73623+00	2026-08-15 21:37:56.26585+00	2026-08-15 21:37:25.710951+00	6
16	\N	Bootstrap	complete	100	dashboard	2026-08-15 21:41:09.841182+00	2026-08-15 21:41:10.403768+00	2026-08-15 21:41:09.81456+00	1
17	\N	Sleep 30s	complete	100	debug	2026-08-15 21:41:37.336939+00	2026-08-15 21:42:07.947309+00	2026-08-15 21:41:37.309763+00	6
18	\N	Sleep 30s	complete	100	dashboard	2026-08-15 21:43:51.483581+00	2026-08-15 21:44:22.009637+00	2026-08-15 21:43:51.393872+00	6
19	\N	Sleep 30s	complete	100	dashboard	2026-08-15 21:50:21.718731+00	2026-08-15 21:50:52.269772+00	2026-08-15 21:50:21.695184+00	6
20	\N	Bootstrap	complete	100	flask-test	2026-08-15 22:08:17.752771+00	2026-08-15 22:08:18.407258+00	2026-08-15 22:08:17.661613+00	1
21	\N	Python smoke test	complete	100	\N	2026-08-15 22:08:36.154497+00	2026-08-15 22:08:36.916912+00	2026-08-15 22:08:36.145733+00	2
22	\N	Sleep 30s	complete	100	flask-test-sleep	2026-08-15 22:08:44.778783+00	2026-08-15 22:09:15.41323+00	2026-08-15 22:08:44.770757+00	6
23	\N	Bootstrap	complete	100	final-check	2026-08-15 22:10:02.845519+00	2026-08-15 22:10:05.219166+00	2026-08-15 22:10:02.78668+00	1
24	\N	Bootstrap	complete	100	dashboard	2026-08-15 22:33:03.382447+00	2026-08-15 22:33:03.998845+00	2026-08-15 22:33:03.371712+00	1
25	\N	Bootstrap	complete	100	dashboard	2026-08-17 05:24:54.00553+00	2026-08-17 05:24:54.779205+00	2026-08-17 05:24:53.991636+00	1
26	\N	Sleep 30s	complete	100	dashboard	2026-08-21 07:07:04.366056+00	2026-08-21 07:07:35.020681+00	2026-08-21 07:07:04.347931+00	6
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: mgmtflow
--

COPY public.workflows (id, name, description, schedule, is_active, created_at, updated_at) FROM stdin;
1	Auto-scale worker pool	Add nodes when CPU > 75% for 5 min	cpu_threshold	t	2026-08-15 20:24:52.503656+00	2026-08-15 20:24:52.503656+00
2	Burst-protect rate limiting	Raise limits temporarily under load spikes	load_spike	t	2026-08-15 20:24:52.503656+00	2026-08-15 20:24:52.503656+00
3	Nightly backups	Snapshot all prod databases	0 23 * * *	t	2026-08-15 20:24:52.503656+00	2026-08-15 20:24:52.503656+00
4	Auto-restart failed pipelines	Retry once before paging on-call	on_failure	f	2026-08-15 20:24:52.503656+00	2026-08-15 20:24:52.503656+00
5	Cost anomaly detection	Alert on spend > 20% above 7-day average	daily	t	2026-08-15 20:24:52.503656+00	2026-08-15 20:24:52.503656+00
\.


--
-- Name: flow_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mgmtflow
--

SELECT pg_catalog.setval('public.flow_definitions_id_seq', 6, true);


--
-- Name: flow_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mgmtflow
--

SELECT pg_catalog.setval('public.flow_tasks_id_seq', 25, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mgmtflow
--

SELECT pg_catalog.setval('public.jobs_id_seq', 26, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: mgmtflow
--

SELECT pg_catalog.setval('public.workflows_id_seq', 5, true);


--
-- Name: flow_definitions flow_definitions_display_id_key; Type: CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_definitions
    ADD CONSTRAINT flow_definitions_display_id_key UNIQUE (display_id);


--
-- Name: flow_definitions flow_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_definitions
    ADD CONSTRAINT flow_definitions_pkey PRIMARY KEY (id);


--
-- Name: flow_tasks flow_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_tasks
    ADD CONSTRAINT flow_tasks_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_flow_tasks_job_id; Type: INDEX; Schema: public; Owner: mgmtflow
--

CREATE INDEX idx_flow_tasks_job_id ON public.flow_tasks USING btree (job_id);


--
-- Name: idx_flow_tasks_status; Type: INDEX; Schema: public; Owner: mgmtflow
--

CREATE INDEX idx_flow_tasks_status ON public.flow_tasks USING btree (status);


--
-- Name: idx_jobs_status; Type: INDEX; Schema: public; Owner: mgmtflow
--

CREATE INDEX idx_jobs_status ON public.jobs USING btree (status);


--
-- Name: idx_jobs_workflow_id; Type: INDEX; Schema: public; Owner: mgmtflow
--

CREATE INDEX idx_jobs_workflow_id ON public.jobs USING btree (workflow_id);


--
-- Name: flow_tasks flow_tasks_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.flow_tasks
    ADD CONSTRAINT flow_tasks_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: jobs jobs_flow_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_flow_definition_id_fkey FOREIGN KEY (flow_definition_id) REFERENCES public.flow_definitions(id) ON DELETE SET NULL;


--
-- Name: jobs jobs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: mgmtflow
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict QccT77WCTbC6yIqckfswnI1a3z7jXhbpvTlyoSTdHIcMxgQhlWEn5tCawiQNzUQ

